source archive stand-in
